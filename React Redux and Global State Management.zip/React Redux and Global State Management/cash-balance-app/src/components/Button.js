// src/components/Button.js
import React from 'react';
import { Button } from 'react-bootstrap';

const CustomButton = ({ onClick, text }) => {
  return (
    <Button onClick={onClick} className="m-2">
      {text}
    </Button>
  );
};

export default CustomButton;
