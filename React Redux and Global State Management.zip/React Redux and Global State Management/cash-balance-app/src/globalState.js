
export const initialState = {
    balance: 0,
  };
  
  export const reducers = (state, action) => {
    switch (action.type) {
      case 'DEPOSIT':
        return { ...state, balance: state.balance + action.payload };
      case 'WITHDRAW':
        return { ...state, balance: state.balance - action.payload };
      case 'ADD_INTEREST':
        return { ...state, balance: state.balance * 1.05 };
      case 'CHARGES':
        return { ...state, balance: state.balance * 0.85 };
      default:
        return state;
    }
  };
  