// src/App.js
import React, { useReducer, useState } from 'react';
import { initialState, reducers } from './globalState';
import CustomButton from './components/Button';

function App() {
  const [state, dispatch] = useReducer(reducers, initialState);
  const [amount, setAmount] = useState(0);

  return (
    <div className="container text-center mt-5">
      <h1>Cash Balance App</h1>
      <h2>Balance: ${state.balance.toFixed(2)}</h2>

      <input
        type="number"
        className="form-control my-3"
        value={amount}
        onChange={(e) => setAmount(parseFloat(e.target.value))}
        placeholder="Enter amount"
      />

      <CustomButton
        onClick={() => dispatch({ type: 'DEPOSIT', payload: amount })}
        text="Deposit"
      />
      <CustomButton
        onClick={() => dispatch({ type: 'WITHDRAW', payload: amount })}
        text="Withdraw"
      />
      <CustomButton
        onClick={() => dispatch({ type: 'ADD_INTEREST' })}
        text="Add Interest (5%)"
      />
      <CustomButton
        onClick={() => dispatch({ type: 'CHARGES' })}
        text="Charges (15%)"
      />
    </div>
  );
}

export default App;
