// src/App.js
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addTodo, deleteTodo, toggleComplete, editTodo } from './features/todoSlice';
import { Button, Modal, Form } from 'react-bootstrap';

function App() {
  const [newTodo, setNewTodo] = useState(''); // State for adding new todo
  const [show, setShow] = useState(false); // Modal control
  const [currentTodo, setCurrentTodo] = useState(null); // State for current todo being edited
  const [editContent, setEditContent] = useState(''); // State for the content being edited
  const todos = useSelector((state) => state.todos.list); // Getting todos from Redux store
  const dispatch = useDispatch();

  // Add a new to-do
  const handleAddTodo = () => {
    if (newTodo.trim()) {
      dispatch(addTodo(newTodo)); // Dispatch addTodo action
      setNewTodo(''); // Clear input after adding
    }
  };

  // Open edit modal and set current to-do content
  const handleEditTodo = (todo) => {
    setCurrentTodo(todo);
    setEditContent(todo.content);
    setShow(true);
  };

  // Save edited to-do
  const handleSaveEdit = () => {
    dispatch(editTodo({ id: currentTodo.id, newContent: editContent }));
    setShow(false);
  };

  return (
    <div className="container mt-5">
      <h1>To-Do App</h1>

      {/* Input for adding new to-do */}
      <div>
        <input
          type="text"
          className="form-control"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          placeholder="Enter new todo"
        />
        <Button className="mt-2" onClick={handleAddTodo}>
          Add To-Do
        </Button>
      </div>

      {/* List of to-dos */}
      <ul className="list-group mt-3">
        {todos.map((todo) => (
          <li key={todo.id} className={`list-group-item ${todo.completed ? 'completed' : ''}`}>
            <span>{todo.content}</span>

            {/* Buttons for Edit, Delete, Complete/Undo */}
            <Button
              variant="warning"
              className="m-2"
              onClick={() => handleEditTodo(todo)}
              disabled={todo.completed} // Disable edit if to-do is completed
            >
              Edit
            </Button>
            <Button
              variant="danger"
              className="m-2"
              onClick={() => dispatch(deleteTodo(todo.id))}
            >
              Delete
            </Button>
            <Button
              variant={todo.completed ? 'secondary' : 'success'}
              className="m-2"
              onClick={() => dispatch(toggleComplete(todo.id))}
            >
              {todo.completed ? 'Undo' : 'Complete'}
            </Button>
          </li>
        ))}
      </ul>

      {/* Edit Modal */}
      <Modal show={show} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit To-Do</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Control
            type="text"
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShow(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSaveEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default App;
